﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mashina_24
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

      

        private void Button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                pictureBox1.Image = Image.FromFile(@"C:\Users\student\Downloads\kia_ceratokoup_1.jpg");
                label2.Text = ("560.000 тысяч рублей");
            }

            if (checkBox2.Checked)
            {
                pictureBox1.Image = Image.FromFile(@"C:\Users\student\Downloads\2.jpg");
                label2.Text = ("789.000 тысяч рублей");
            }

            if (checkBox3.Checked)
            {
                pictureBox1.Image = Image.FromFile(@"C:\Users\student\Downloads\3.jpg");
                label2.Text = ("900.000 тысяч рублей");
            }
        }

       
    }
}
